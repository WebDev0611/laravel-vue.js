/**
 * Init File For 360 Tour Viewer
 */

import AppContainer from './360Viewer/AppContainer.js';

// Create Global App Container
const APPCONTAINER = new AppContainer();