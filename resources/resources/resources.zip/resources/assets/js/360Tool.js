/**
 * Init File For 360 Tour Upload Tool
 */

import AppContainer from './360Tool/AppContainer.js';

// Create Global App Container
const APPCONTAINER = new AppContainer();